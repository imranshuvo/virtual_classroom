<?php $__env->startSection('content'); ?>


<?php
    $image = basename($course->large_url);
?>


<section class="bg-dark">
    <div class="container">
        <div class="row p-t-xxl">
            <div class="col-sm-8 col-sm-offset-2 p-v-xxl text-center">
                <h1 class="h1 m-t-l p-v-l"><?php echo e($course->title); ?></h1>
            </div>
        </div>
    </div>
</section>

    
<section class="p-v-xxl bg-light">
    <div class="container">
        <div class="row p-t-xxl content">

            <div class="row">
                <!--blog post -->
                <div class="col-sm-8">
                    
                    <!--post -->
                    <div class="panel">
                        <div class="">
                            <?php if($errors->any()): ?>
                                <div class="pos-rlt wrapper b b-light r r-2x bg-danger">
                                    <span class="arrow left pull-up arrow-danger"></span>
                                    <p class="m-b-none text-white"><?php echo e($errors->first()); ?></p>
                                </div>
                            <?php endif; ?>
                            <?php if(session('message')): ?>
                                <div class="pos-rlt wrapper b b-light r r-2x bg-success">
                                    <span class="arrow left pull-up arrow-success"></span>
                                    <p class="m-b-none text-white"><?php echo e(session('message')); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(isset($message)): ?>
                                <div class="pos-rlt wrapper b b-light r r-2x bg-success">
                                    <span class="arrow left pull-up arrow-success"></span>
                                    <p class="m-b-none text-white"><?php echo e($message); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="item img-bg img-info">
                            <?php if(!empty($image)): ?>
                                <img src="<?php echo e(asset('course/imgs')); ?>/<?php echo $image ?>" class="img-full">
                            <?php else: ?>
                                <img src="<?php echo e(asset('course/imgs/no')); ?>/placeholder.png" class="img-full">
                            <?php endif; ?>
                        </div>
                        <div class="bottom wrapper-lg w-full">
                            <h4 class="h4 text-inline"><a class="text" href=""><?php echo e($course->title); ?></a></h4>
                            <small class="">Published : <?php echo e(date('j F,Y',strtotime($course->created_at ))); ?></small>
                        </div>
                        <div class="wrapper-lg">
                            <a href="" class="m-r-xl"><span><?php echo e($enrolled); ?></span> Students Enrolled</a>
                            <a href=""><span><?php echo e($seat_left); ?></span> Seat Left</a>    
                            <a href="<?php echo e(url('course')); ?>/<?php echo e($course->id); ?>/class" class="btn btn-danger pull-right"> Join Class </a>
                        </div>
                        <div class="wrapper b-b">
                            <p class="m-b-none">
                                <?php echo $course->description; ?>

                            </p>
                        </div>
                        
                    </div>
                    <!--/ post -->
                    
                </div>
                <!--/ blog post -->

                <!--blog sidebar -->
                <div class="col-sm-4">
                    <div class="panel wrapper-xxl bg-offWhite">
                        <h5 class="m-t-none m-b-lg">Information</h5>
                        <div class="">
                            <p>Call No :  <b><?php echo e($user->email); ?>_<?php echo e($course->id); ?></b></p>
                        </div>
                        <div class="">
                            <div class="line-sm b-b"></div>
                        </div>
                        <div class="">
                            <p>Start Date: <b><?php echo e(date('j F,Y',strtotime($course->start_date ))); ?></b></p>
                        </div>
                        <div class="">
                            <div class="line-sm b-b"></div>
                        </div>
                        <div class="">
                            <p><a href="<?php echo e(url('course')); ?>/<?php echo e($course->id); ?>/class" class="btn btn-danger">Join Class</a></p>
                        </div>
                    </div>
                    <div class="panel wrapper-xxl bg-offWhite">
                        <div class="">
                            <a href="<?php echo e(url('exam/course')); ?>/<?php echo e($course->id); ?>/topic/all"> Exams </a>
                        </div>
                        <div class="">
                            <div class="line-sm b-b"></div>
                        </div>
                    </div>
                    <div class="panel wrapper-xxl bg-offWhite text-center">
                        <h5 class="m-t-none m-b-lg">Instructor Biography</h5>
                        <div class="">
                            <?php if(!empty($user->profile_photo)): ?>
                                <img src="<?php echo e(url($user->profile_photo)); ?>" class="img-full">
                            <?php else: ?>
                                <img src="<?php echo e(url('user/no_photo/no_photo.png')); ?>" class="img-full">
                            <?php endif; ?>
                        </div>
                        <div class="text-center">
                            <h4><?php echo e($user->name); ?></h4>
                            <h6><?php echo e($user->designation); ?></h6>
                            <p><?php echo e($user->biography); ?></p>
                        </div>
                    </div>
                </div>
                <!--/ blog sidebar -->
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>