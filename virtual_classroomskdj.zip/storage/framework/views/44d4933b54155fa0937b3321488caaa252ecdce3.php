<?php $__env->startSection('content'); ?>


<?php 

	$image = basename($course->large_url);

?>


<section class="bg-dark">
    <div class="container">
        <div class="row p-t-xxl">
            <div class="col-sm-8 col-sm-offset-2 p-v-xxl text-center">
                <h1 class="h1 m-t-l p-v-l"><?php echo e($course->title); ?></h1>
            </div>
        </div>
    </div>
</section>



<section class="p-v-xxl bg-light">
    <div class="row p-t-xxl ">
    	<div class="container content">
    		<div class="row">
				<!--blog post -->
				<div class="col-sm-8">
					
					<!--post -->
					<div class="panel">
						<div class="">
							<?php if($errors->any()): ?>
                                <div class="pos-rlt wrapper b b-light r r-2x bg-danger">
                                    <span class="arrow left pull-up arrow-danger"></span>
                                    <p class="m-b-none text-white"><?php echo e($errors->first()); ?></p>
                                </div>
                            <?php endif; ?>
                            <?php if(session('message')): ?>
                                <div class="pos-rlt wrapper b b-light r r-2x bg-success">
                                    <span class="arrow left pull-up arrow-success"></span>
                                    <p class="m-b-none text-white"><?php echo e(session('message')); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(isset($message)): ?>
                                <div class="pos-rlt wrapper b b-light r r-2x bg-success">
                                    <span class="arrow left pull-up arrow-success"></span>
                                    <p class="m-b-none text-white"><?php echo e($message); ?></p>
                                </div>
                            <?php endif; ?>
						</div>
						<div class="item img-bg img-info">
							<?php if(!empty($image)): ?>
	                        	<img src="<?php echo e(asset('course/imgs')); ?>/<?php echo $image ?>" class="img-full">
	                        <?php else: ?>
	                            <img src="<?php echo e(asset('course/imgs/no')); ?>/placeholder.png" class="img-full">
	                        <?php endif; ?>
						</div>
						<div class="bottom wrapper-lg w-full">
							<h4 class="h4 text-inline"><a class="text" href=""><?php echo e($course->title); ?></a></h4>
							<small class="">Published : <?php echo e(date('j F,Y',strtotime($course->created_at ))); ?></small>
						</div>
						<div class="wrapper-lg">
							<a href="" class="m-r-xl"><span><?php echo e($enrolled); ?></span> Students Enrolled</a>
							<a href=""><span><?php echo e($seat_left); ?></span> Seat Left</a>
							<form action="<?php echo e(url('course')); ?>/<?php echo e($course->id); ?>/enroll" method="get" class="enroll-btn">
								<div class="form-group">
									<button type="submit" class="form-control pull-right btn btn-primary" value="Enroll">Enroll in This Course</button>
								</div>
					      	</form>
							
						</div>
						<div class="wrapper b-b">
							<p class="m-b-none">
								<?php echo $course->description; ?>

							</p>
						</div>
						
					</div>
					<!--/ post -->
					
				</div>
				<!--/ blog post -->

				<!--blog sidebar -->
				<div class="col-sm-4">
					<div class="panel wrapper-xxl bg-offWhite text-center">
						<h5 class="m-t-none m-b-lg">Instructor Biography</h5>
						<div class="">
							<?php if(!empty($user->profile_photo)): ?>
                                <img src="<?php echo e(url($user->profile_photo)); ?>" class="img-full">
                            <?php else: ?>
                                <img src="<?php echo e(url('user/no_photo/no_photo.png')); ?>" class="img-full">
                            <?php endif; ?>
						</div>
						<div class="text-center">
							<h4><?php echo e($user->name); ?></h4>
							<h6><?php echo e($user->designation); ?></h6>
							<p><?php echo e($user->biography); ?></p>
						</div>
					</div>
					
					<?php if(count($all_courses) > 0): ?>
						<div class="panel wrapper-xxl bg-offWhite">
							<h5 class="m-t-none m-b-lg text-center">Check My Other Courses</h5>
							<?php foreach($all_courses as $course): ?>
							<div class="">
								<?php $image = basename($course->thumb_url); ?>
								<?php if(!empty($image)): ?>
									<a herf="<?php echo e(url('course')); ?>/<?php echo e($course->id); ?>" class="pull-left thumb-md b m-r-sm"> <img src="<?php echo e(asset('course/imgs')); ?>/<?php echo $image;?>" alt="..." class="img-full"> </a>
								<?php else: ?>
									<a herf="<?php echo e(url('course')); ?>/<?php echo e($course->id); ?>" class="pull-left thumb-md b m-r-sm"> <img src="<?php echo e(asset('course/imgs')); ?>/no/placeholder.png" alt="..." class="img-full"> </a>
								<?php endif; ?>
								<div class="clear">
									<a href="<?php echo e(url('course')); ?>/<?php echo e($course->id); ?>" class="text-info text-ellipsis"><?php echo e($course->title); ?></a>
									<small class="block text-muted">Start Date: <?php echo e(date('j F,Y',strtotime($course->start_date))); ?></small>
								</div>
							</div>
							<div class="line-sm"></div>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>

				</div>
				<!--/ blog sidebar -->
			</div>
		</div>
	</div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>