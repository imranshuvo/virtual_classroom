<?php $__env->startSection('content'); ?>
<section class="bg-dark">
    <div class="container">
        <div class="row p-t-xxl">
            <div class="col-sm-8 col-sm-offset-2 p-v-xxl text-center">
                <h3 class="h3 m-t-l p-v-l">Exam : <b><?php echo e($topic->name); ?></b></h3>
                <h3 class="h3 m-t-l p-v-l">Duration : <b><?php echo e($topic->duration); ?> minutes</b></h3>
                <?php echo e(session('next_question_id')); ?>

            </div>
        </div>
    </div>
</section>

    
<section class="p-v-xxl bg-light">
    <div class="container">
        <div class="row p-t-xxl bg-info content">
                <!-- Clock counter -->
        	   <div id="counter1"></div>

               <!-- js for the clock running -->
               <?php $__env->startSection('script_clock'); ?>
                    $(function() {
                        var clock = $('#counter1').FlipClock(<?php echo e($duration*60); ?>, {
                            autoStart: false,
                            countdown: true,
                            clockFace: 'MinuteCounter',
                            callbacks: {
                                 interval: function () {
                                     var time = clock.getTime().time;
                                     //alert(time);
                                    <?php foreach($questions as $q): ?>
                                        $('#time_taken<?php echo e($q->id); ?>').val(time);
                                    <?php endforeach; ?>
                                },
                            stop: function(){
                            alert("The time has run out!");
                            }

                    }
                    });
                    clock.start();

                <?php $__env->stopSection(); ?>



                <?php foreach($questions as $question): ?>
                    <div class="jumbotron" id="jumbotron<?php echo e($question->id); ?>"
                            <?php if($question->id != $current_question_id ): ?>
                                    style="display:none";
                            <?php endif; ?>
                            >
                        <p>Question #<?php echo e($question->id); ?></p>
                        <p><?php echo e($question->question); ?></p>

                        <form class="form-horizontal" method="post" id="frm<?php echo e($question->id); ?>" action="<?php echo e(action('ExamController@postSaveQuestionResult',[$course->id,$topic->id])); ?>">
                            
                            <ul id="answer-radio<?php echo e($question->id); ?>">
                                <div class="btn-group" data-toggle="buttons">
                                    <li>
                                        <label><input type="radio" name="option" value="1" /> <?php echo e($question->option1); ?></label>
                                    </li>
                                    <li>
                                        <label><input type="radio" name="option" value="2" /> <?php echo e($question->option2); ?></label>
                                    </li>
                                    <li>
                                        <label><input type="radio" name="option" value="3" /> <?php echo e($question->option3); ?></label>
                                    </li>
                                    <li>
                                        <label><input type="radio" name="option" value="4" /> <?php echo e($question->option4); ?></label>
                                    </li>
                                </div>
                            </ul>
                            <input type="hidden" name="question_id" value="<?php echo e($question->id); ?>">
                            <input type="hidden" name="time_taken<?php echo e($question->id); ?>" id="time_taken<?php echo e($question->id); ?>">
                             <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                            <?php if($question->id == $last_question_id): ?>
                                <button type="submit" class="btn btn-primary">Last</button>
                            <?php else: ?>
                                <button type="submit" class="btn btn-primary">Next</button>
                            <?php endif; ?>
                        </form>
                    </div>




                     <?php if($questions->count()>1): ?>
                        <?php $__env->startSection('script_form'); ?>
                            $(function() {

                            console.log(<?php echo e($question->id); ?>);
                            console.log(<?php echo e($last_question_id); ?>);

                                $('#frm<?php echo $question->id; ?>').on('submit', function(e){
                                    e.preventDefault();
                                    var form = $(this);
                                    var $formAction = form.attr('action');
                                    var $userAnswer = $('input[name=option]:checked', $('#frm<?php echo e($question->id); ?>')).val();
                                    $.post($formAction, $(this).serialize(), function(data){
                                        //console.log(this);
                                        $('#jumbotron<?php echo e($question->id); ?>').hide();
                                        $('#jumbotron' + data.next_question_id+'').show();
                                   });



                                });
                            });

                            });
                        <?php $__env->stopSection(); ?>
                    <?php endif; ?>
                <?php endforeach; ?>

        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>