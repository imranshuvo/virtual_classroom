 <section class="bg-info">
            <div class="container">
                <div class="row">
                    <div class="col-sm-8 col-sm-offset-2 p-v-xxl text-center">
                        <h1 class="h1 m-t-xxl p-v-xxl">Blog</h1>
                    </div>
                </div>
            </div>
        </section>

    <div class="container">