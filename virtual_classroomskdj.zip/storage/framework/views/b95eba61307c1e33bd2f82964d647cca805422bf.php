<?php $__env->startSection('content'); ?>


<?php
    $image = basename($course->large_url);
?>


<section class="bg-dark">
    <div class="container">
        <div class="row p-t-xxl">
            <div class="col-sm-8 col-sm-offset-2 p-v-xxl text-center">
                <h1 class="h1 m-t-l p-v-l"><?php echo e($course->title); ?></h1>
            </div>
        </div>
    </div>
</section>

	
<section class="p-v-xxl bg-light">
	<div class="container">
	    <div class="row p-t-xxl content">

            <div class="row">
                <!--blog post -->
                <div class="col-sm-8">
                    
                    <!--post -->
                    <div class="panel">
                        <div class="">
                            <?php if($errors->any()): ?>
                                <div class="pos-rlt wrapper b b-light r r-2x bg-danger">
                                    <span class="arrow left pull-up arrow-danger"></span>
                                    <p class="m-b-none text-white"><?php echo e($errors->first()); ?></p>
                                </div>
                            <?php endif; ?>
                            <?php if(session('message')): ?>
                                <div class="pos-rlt wrapper b b-light r r-2x bg-success">
                                    <span class="arrow left pull-up arrow-success"></span>
                                    <p class="m-b-none text-white"><?php echo e(session('message')); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(isset($message)): ?>
                                <div class="pos-rlt wrapper b b-light r r-2x bg-success">
                                    <span class="arrow left pull-up arrow-success"></span>
                                    <p class="m-b-none text-white"><?php echo e($message); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="item img-bg img-info">
                            <?php if(!empty($image)): ?>
                                <img src="<?php echo e(asset('course/imgs')); ?>/<?php echo $image ?>" class="img-full">
                            <?php else: ?>
                                <img src="<?php echo e(asset('course/imgs/no')); ?>/placeholder.png" class="img-full">
                            <?php endif; ?>
                        </div>
                        <div class="bottom wrapper-lg w-full">
                            <h4 class="h4 text-inline"><a class="text" href=""><?php echo e($course->title); ?></a></h4>
                            <small class="">Published : <?php echo e(date('j F,Y',strtotime($course->created_at ))); ?></small>
                        </div>
                        <div class="wrapper-lg">
                            <a href="" class="m-r-xl"><span><?php echo e($enrolled); ?></span> Students Enrolled</a>
                            <a href=""><span><?php echo e($seat_left); ?></span> Seat Left</a>
                            <form action="<?php echo e(url('course')); ?>/<?php echo e($course->id); ?>/enroll" method="get" class="enroll-btn">
                                <div class="form-group">
                                    <button type="submit" class="form-control pull-right btn btn-primary" value="Enroll">Enroll in This Course</button>
                                </div>
                            </form>
                            
                        </div>
                        <div class="wrapper b-b">
                            <p class="m-b-none">
                                <?php echo $course->description; ?>

                            </p>
                        </div>
                        
                    </div>
                    <!--/ post -->
                    
                </div>
                <!--/ blog post -->

                <!--blog sidebar -->
                <div class="col-sm-4">

                    <div class="panel wrapper-xxl bg-offWhite text-center">
                        <div id="inCall" class="ptext">
                            <a href="" class="btn btn-danger" data-toggle="modal" data-target="#editCourse"><i class="fa fa-edit"></i> Edit</a> 
                            <a href="" class="btn btn-danger" data-toggle="modal" data-target="#deleteCourse"><i class="fa fa-remove"></i> Delete</a>
                        </div>
                    </div>
                    <div class="panel wrapper-xxl bg-offWhite">
                        <div class="">
                            <a href="<?php echo e(url('course')); ?>/<?php echo e($course->id); ?>/class" class="btn btn-danger"> Goto Class </a>
                        </div>
                        <div class="">
                            <div class="line-sm b-b"></div>
                        </div>
                        <div class="">
                            <a href="<?php echo e(url('exam/course')); ?>/<?php echo e($course->id); ?>/topic/all">  All Exam Topics </a>
                        </div>
                        <div class="">
                            <div class="line-sm b-b"></div>
                        </div>
                        <div class="">
                            <a href="<?php echo e(url('exam/course')); ?>/<?php echo e($course->id); ?>/topic/new">  + Create an Exam Topic </a>
                        </div>
                        <div class="">
                            <div class="line-sm b-b"></div>
                        </div>
                    </div>
                    <div class="panel wrapper-xxl bg-offWhite text-center">
                        <h5 class="m-t-none m-b-lg">Instructor Biography</h5>
                        <div class="">
                            <?php if(!empty($user->profile_photo)): ?>
                                <img src="<?php echo e(url($user->profile_photo)); ?>" class="img-full">
                            <?php else: ?>
                                <img src="<?php echo e(url('user/no_photo/no_photo.png')); ?>" class="img-full">
                            <?php endif; ?>
                        </div>
                        <div class="text-center">
                            <h4><?php echo e($user->name); ?></h4>
                            <h6><?php echo e($user->designation); ?></h6>
                            <p><?php echo e($user->biography); ?></p>
                        </div>
                    </div>
                    
                    <?php if(count($all_courses) > 0): ?>
                        <div class="panel wrapper-xxl bg-offWhite">
                            <h5 class="m-t-none m-b-lg text-center">Check My Other Courses</h5>
                            <?php foreach($all_courses as $all_course): ?>
                            <div class="">
                                <?php $image = basename($course->thumb_url); ?>
                                <?php if(!empty($image)): ?>
                                    <a herf="<?php echo e(url('course')); ?>/<?php echo e($all_course->id); ?>" class="pull-left thumb-md b m-r-sm"> <img src="<?php echo e(asset('course/imgs')); ?>/<?php echo $image;?>" alt="..." class="img-full"> </a>
                                <?php else: ?>
                                    <a herf="<?php echo e(url('course')); ?>/<?php echo e($all_course->id); ?>" class="pull-left thumb-md b m-r-sm"> <img src="<?php echo e(asset('course/imgs')); ?>/no/placeholder.png" alt="..." class="img-full"> </a>
                                <?php endif; ?>
                                <div class="clear">
                                    <a href="<?php echo e(url('course')); ?>/<?php echo e($all_course->id); ?>" class="text-info text-ellipsis"><?php echo e($course->title); ?></a>
                                    <small class="block text-muted">Start Date: <?php echo e(date('j F,Y',strtotime($course->start_date))); ?></small>
                                </div>
                            </div>
                            <div class="line-sm"></div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
                <!--/ blog sidebar -->
            </div>


                <div class="col-md-9">
                    <!-- Main content -->
                    <!-- Modals -->
                    <div class="row">
                        <!-- Edit Course Modal -->
                        <div id="editCourse" class="modal fade bs-example-modal-lg" role="dialog">
                            <div class="modal-dialog modal-lg">

                                <!-- Modal content-->
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Edit course</h4>
                                  </div>
                                  <div class="modal-body">
                                        <form class="form-horizontal" role="form" action="<?php echo e(url('course')); ?>/<?php echo e($course->id); ?>/update" method="post" enctype="Multipart/form-data">
                                        <?php echo e(csrf_field()); ?>

                                            
                                            <div class="form-group">
                                                <label for="class_number" class="col-sm-2 control-label">Number of Classes</label>
                                                <div class="col-sm-10">
                                                    <input type="number" name="class_number" class="form-control" value="<?php echo e($course->class_number); ?>" required="">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="class_number" class="col-sm-2 control-label">Maximum Allowed Students ( max 20 )</label>
                                                <div class="col-sm-10">
                                                    <input type="number" name="max_allowed_student" value="<?php echo e($course->max_allowed_student); ?>" class="form-control" min="1" max="20" required="">
                                                </div>
                                            </div>
                                           
                                            <div class="form-group">
                                                <label for="class_number" class="col-sm-2 control-label">Description</label>
                                                <div class="col-sm-10">
                                                    <textarea name="description" class="form-control" id="summernote" cols="30" rows="10" required=""><?php echo $course->description; ?></textarea>
                                                </div>
                                            </div>
                                        
                                            <div class="form-group">        
                                                <div class="col-sm-offset-2 col-sm-10">
                                                    <button type="submit" class="btn btn-primary">Submit</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    </div>
                                </div>

                              </div>
                        </div>

                        <!-- Delete Course modal -->
                        <div id="deleteCourse" class="modal fade" role="dialog">
                            <div class="modal-dialog">

                                <!-- Modal content-->
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Delete course</h4>
                                  </div>
                                  <div class="modal-body">
                                      <p>Are you sure you want to delete this course ? This can't be reverted!</p>
                                  </div>
                                  <div class="modal-footer">
                                        <form class="form-vertical" method="post" action="<?php echo e(url('course')); ?>/<?php echo e($course->id); ?>/delete">
                                            <?php echo e(csrf_field()); ?>

                                            <div class="form-group">
                                                <button type="submit" href="<?php echo e(url('course')); ?>/<?php echo e($course->id); ?>/delete" class="btn btn-danger">Confirm</button>
                                            </div>
                                        </form>
                                       
                                       <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                                  </div>
                                </div>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>
    	    </div>
        </div>
	</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>