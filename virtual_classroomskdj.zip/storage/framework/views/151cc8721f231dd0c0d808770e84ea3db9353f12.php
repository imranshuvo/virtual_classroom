<?php $__env->startSection('content'); ?>


<section class="bg-dark">
    <div class="container">
        <div class="row p-t-xxl">
            <div class="col-sm-8 col-sm-offset-2 p-v-xxl text-center">
                <h1 class="h1 m-t-l p-v-l">All Courses</h1>
            </div>
        </div>
    </div>
</section>

	
<section class="p-v-xxl bg-light">
	<div class="container">
	    <div class="row p-t-xxl">

            <?php if(session('message')): ?>
                <div class="pos-rlt wrapper b b-light r r-2x bg-success">
                    <span class="arrow left pull-up arrow-success"></span>
                    <p class="m-b-none text-white"><?php echo e(session('message')); ?></p>
                </div>
            <?php endif; ?>



			<?php if($errors->has()): ?>
				<?php foreach($errors->all() as $error): ?>
				  <div class="pos-rlt wrapper b b-light r r-2x bg-danger">
                      <span class="arrow left pull-up arrow-danger"></span>
                      <p class="m-b-none text-white"><?php echo e($error); ?></p>
                  </div>
				<?php endforeach; ?>
			<?php endif; ?>


			

			<?php if(count($courses) > 0): ?>
				<?php foreach($courses as $course): ?>

					<div class="col-md-3 single-course-box">
							<a href="<?php echo e(url('course')); ?>/<?php echo e($course->id); ?>" >
					  
							<?php 

								$image = basename($course->thumb_url);

							?>
							<div class="item text-center bg-info">
								<div class="top-image course-image">
									<img src="<?php echo e(asset('course/imgs/')); ?>/<?php echo $image ?> " class="">
								</div>
								<div class="course-course-title">
									<h5><?php echo e($course->title); ?></h5>
									<div class="line line-lg b-b b-info w-3x m-auto"></div>
								</div>	
								<div class="w-full p-h-xxl p-v-lg">
									<p class="h6"><b>By:</b> <?php echo e($course->name); ?></p>
									<h6>Start Date: <span class="text-info"><?php echo e(date('j F,Y',strtotime($course->start_date))); ?></span></h6>
									<!-- <h6>Allowed Students: <?php echo e($course->max_allowed_student); ?></h6>
									<h6>Number of Classes: <?php echo e($course->class_number); ?></h6>	 -->							
								</div>						
							</div>
						</a>
					</div>
				<?php endforeach; ?>
			<?php else: ?>

				<div class="media-body">
			    	<div class="pos-rlt wrapper b b-light r r-2x bg-danger">
	                	<span class="arrow left pull-up arrow-danger"></span>
	                	<p class="m-b-none">Sorry, no courses found ! Please try again!</p>
	              	</div>
			  	</div>

			<?php endif; ?>
	    </div>
	</div>
</section>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>