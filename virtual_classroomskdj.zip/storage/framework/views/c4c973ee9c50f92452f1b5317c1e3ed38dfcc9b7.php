<?php $__env->startSection('content'); ?>
    <div id="edit-post">
        <h2><?php echo e(trans('forum::posts.edit')); ?> (<?php echo e($thread->title); ?>)</h2>

        <hr>

        <?php if(!$post->isFirst): ?>
            <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('delete', $post)): ?>
                <form action="<?php echo e(Forum::route('post.update', $post)); ?>" method="POST" data-actions-form>
                    <?php echo csrf_field(); ?>

                    <?php echo method_field('delete'); ?>


                    <?php echo $__env->make('forum::post.partials.actions', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </form>
            <?php endif; ?>
        <?php endif; ?>

        <?php if($post->parent): ?>
            <h3><?php echo e(trans('forum::general.response_to', ['item' => $post->parent->authorName])); ?>...</h3>

            <?php echo $__env->make('forum::post.partials.excerpt', ['post' => $post->parent], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(Forum::route('post.update', $post)); ?>">
            <?php echo csrf_field(); ?>

            <?php echo method_field('patch'); ?>


            <div class="form-group">
                <textarea name="content" class="form-control"><?php echo e(!is_null(old('content')) ? old('content') : $post->content); ?></textarea>
            </div>

            <button type="submit" class="btn btn-success pull-right"><?php echo e(trans('forum::general.proceed')); ?></button>
            <a href="<?php echo e(URL::previous()); ?>" class="btn btn-danger"><?php echo e(trans('forum::general.cancel')); ?></a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('forum::master', ['breadcrumb_other' => trans('forum::posts.edit')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>