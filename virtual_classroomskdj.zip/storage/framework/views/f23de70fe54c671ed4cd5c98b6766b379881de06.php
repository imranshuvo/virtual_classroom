<?php $__env->startSection('content'); ?>
<section class="bg-dark">
    <div class="container">
        <div class="row p-t-xxl">
            <div class="col-sm-8 col-sm-offset-2 p-v-xxl text-center">
                <h1 class="h1 m-t-l p-v-l">Create New topic of <b><?php echo e($course->title); ?></b></h1>
            </div>
        </div>
    </div>
</section>

    
<section class="p-v-xxl bg-light">
    <div class="container">
        <div class="row p-t-xxl bg-info content">
        	<?php echo $__env->make('errors.list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="col-md-3">
                <!-- left sidebar -->
                <div class="list-group">
                    <a href="<?php echo e(url('teacher/my-course')); ?>/<?php echo e($course->id); ?>" class="list-group-item"><< Back to course page</a>
                    <a href="<?php echo e(url('exam/course')); ?>/<?php echo e($course->id); ?>/topic/all" class="list-group-item">All exam topic</a>

                </div>
            </div>

            <div class="col-md-9">

            	<form class="form-horizontal" action="<?php echo e(url('exam/course')); ?>/<?php echo e($course->id); ?>/topic/create" method="post">
            		<?php echo e(csrf_field()); ?>


                    <div class="form-group">
                        <div class="col-md-2">
                            <label for="topic-name">Name of Topic</label>
                        </div>
                        <div class="col-md-10">
                            <input type="text" class="form-control" name="name" required="" placeholder="Name of the exam topic">
                        </div>
                    </div>

                    <div class="form-group">
                        <input type="hidden" name="course" value="<?php echo e($course->id); ?>">
                    </div>

                    <div class="form-group">
                        <div class="col-md-2">
                            <label for="topic-name">Duration</label>
                        </div>
                        <div class="col-md-10">
                            <input type="text" class="form-control" name="duration" required="" placeholder="Duration of the exam in minutes">
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-md-2">
                            <label for="topic-name">Active</label>
                        </div>
                        <div class="col-md-3">
                            <input type="checkbox" name="status" value="1" checked="checked">
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-md-10 text-center">
                            <button type="submit" class="btn btn-primary"> Create exam topic </button>
                        </div>
                    </div>

            	</form>
            </div>

        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>