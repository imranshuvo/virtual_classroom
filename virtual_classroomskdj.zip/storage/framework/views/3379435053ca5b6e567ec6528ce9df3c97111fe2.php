<?php $__env->startSection('content'); ?>
<section class="bg-dark">
    <div class="container">
        <div class="row p-t-xxl">
            <div class="col-sm-8 col-sm-offset-2 p-v-xxl text-center">
                <h1 class="h1 m-t-l p-v-l">Question Management : <b><?php echo e($topic->name); ?></b></h1>
            </div>
        </div>
    </div>
</section>

    
<section class="p-v-xxl bg-light">
    <div class="container">
        <div class="row p-t-xxl bg-info content">
            <?php echo $__env->make('errors.list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php if(Session::has('flash_mess')): ?>
                <div class="alert alert-success"><?php echo e(Session::get('flash_mess')); ?></div>
            <?php endif; ?>

            <div class="col-md-3">
                <!-- left sidebar -->
                <div class="list-group">
                    <a href="<?php echo e(url('teacher/my-course')); ?>/<?php echo e($course->id); ?>" class="list-group-item"><< Back to course page</a>
                    <a href="<?php echo e(url('exam/course')); ?>/<?php echo e($course->id); ?>/topic/all" class="list-group-item">All exam topic</a>
                    <a href="<?php echo e(url('exam/course')); ?>/<?php echo e($course->id); ?>/topic/new" class="list-group-item">+ Create an exam topic</a>
                </div>
            </div>

            <div class="col-md-9">
                <div class="row">
                    <div class="question-topic">
                        <h3>Course Name: <b><?php echo e($course->title); ?></b></h3>
                        <h3>Topic Name: <b><?php echo e($topic->name); ?></b></h3>
                        <h3>Duration: <b><?php echo e($topic->duration); ?></b> minutes</h3>
                    </div>
                </div>
                <div class="row">
                     <button type="button" class="btn btn-primary" id="btn-add-new-question"><span class="glyphicon glyphicon-plus"></span> Add new question</button>

                     <br><br><br>
                     <form class="form-horizontal" method="post" action="<?php echo e(url('exam/course')); ?>/<?php echo e($course->id); ?>/topic/<?php echo e($topic->id); ?>/question/create" id="add-new-question">
                         <?php echo $__env->make('vendor.exam.question-form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                </div>

                <div class="row"> 
                    <?php if(!$questions->isEmpty()): ?>
                        <div class="panel panel-default">
                            <!-- Default panel contents -->
                            <div class="panel-heading"><span class="glyphicon glyphicon-cog"></span> Questions added</div>

                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                            <?php foreach($questions as $question): ?>

                                    <div class="panel panel-default">
                                        <div class="panel-heading" role="tab" id="heading<?php echo e($question->id); ?>">
                                            <h4 class="panel-title">
                                                <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo e($question->id); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($question->id); ?>">
                                                    Question #<?php echo e($question->id); ?> : <b><?php echo e($question->question); ?></b>
                                                </a>
                                            </h4>
                                        </div>
                                        <div id="collapse<?php echo e($question->id); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading<?php echo e($question->id); ?>">
                                            <div class="panel-body">
                                                <form class="form-horizontal" id="add-new-question" method="post" action="<?php echo e(url('exam/course')); ?>/<?php echo e($course->id); ?>/topic/<?php echo e($topic->id); ?>/question/<?php echo e($question->id); ?>/update">
                                                <?php echo $__env->make('vendor.exam.question-form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                                            </div>
                                        </div>
                                    </div>

                            <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>