<?php if(Auth::check()): ?>
<script src="/vendor/confer/js/confer.js"></script>
<script>
String.prototype.capitalize = function() {
    return this.charAt(0).toUpperCase() + this.slice(1);
};

(function ($, undefined) {
    $.fn.getCursorPosition = function() {
        var el = $(this).get(0);
        var pos = 0;
        if('selectionStart' in el) {
            pos = el.selectionStart;
        } else if('selection' in document) {
            el.focus();
            var Sel = document.selection.createRange();
            var SelLength = document.selection.createRange().text.length;
            Sel.moveStart('character', -el.value.length);
            pos = Sel.text.length - SelLength;
        }
        return pos;
    }
})(jQuery);

(function() {
	var options = {
		pusher_key : "<?php echo e(config('services.pusher.public')); ?>",
		base_url : "<?php echo e(url('/')); ?>",
		avatar_dir : "<?php echo e(url('/') . config('confer.avatar_dir')); ?>",
		token : "<?php echo e(csrf_token()); ?>",
		loader : "<?php echo e(config('confer.loader')); ?>",
        requested_conversations : <?php echo e(Session::has('confer_requested_conversations') ? json_encode(Session::get('confer_requested_conversations')) : '[]'); ?>,
        use_emoji : "<?php echo e(config('confer.enable_emoji')); ?>",
		grammar_enforcer : "<?php echo e(config('confer.grammar_enforcer')); ?>"
	};
	var confer = new window.Confer($('div.confer-overlay'), $('ul.confer-open-conversations-list'), <?php echo e(Auth::user()->id); ?>, options);
})();
</script>
<?php endif; ?>