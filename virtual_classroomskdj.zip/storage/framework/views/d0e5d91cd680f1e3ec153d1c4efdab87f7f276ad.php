<?php if(Session::has('alerts')): ?>
    <?php foreach(Session::get('alerts') as $alert): ?>
        <?php echo $__env->make('forum::partials.alert', $alert, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endforeach; ?>
<?php endif; ?>

<?php if(isset($errors) && !$errors->isEmpty()): ?>
    <?php foreach($errors->all() as $error): ?>
        <?php echo $__env->make('forum::partials.alert', ['type' => 'danger', 'message' => $error], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endforeach; ?>
<?php endif; ?>
