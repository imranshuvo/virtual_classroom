<?php $__env->startSection('content'); ?>
    <div id="create-post">
        <h2><?php echo e(trans('forum::general.new_reply')); ?> (<?php echo e($thread->title); ?>)</h2>

        <?php if(!is_null($post) && !$post->trashed()): ?>
            <h3><?php echo e(trans('forum::general.replying_to', ['item' => $post->authorName])); ?>...</h3>

            <?php echo $__env->make('forum::post.partials.excerpt', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(Forum::route('post.store', $thread)); ?>">
            <?php echo csrf_field(); ?>

            <?php if(!is_null($post)): ?>
                <input type="hidden" name="post" value="<?php echo e($post->id); ?>">
            <?php endif; ?>

            <div class="form-group">
                <textarea name="content" class="form-control"><?php echo e(old('content')); ?></textarea>
            </div>

            <button type="submit" class="btn btn-success pull-right"><?php echo e(trans('forum::general.reply')); ?></button>
            <a href="<?php echo e(URL::previous()); ?>" class="btn btn-danger"><?php echo e(trans('forum::general.cancel')); ?></a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('forum::master', ['breadcrumb_other' => trans('forum::general.new_reply')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>