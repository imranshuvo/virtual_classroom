<?php $__env->startSection('content'); ?>
<section class="bg-dark">
    <div class="container">
        <div class="row p-t-xxl">
            <div class="col-sm-8 col-sm-offset-2 p-v-xxl text-center">
                <h1 class="h1 m-t-l p-v-l"><?php echo e($course->title); ?></h1>
            </div>
        </div>
    </div>
</section>

    
<section class="p-v-xxl bg-light">
    <div class="container">
        <div class="row p-t-xxl content">
        	<?php echo $__env->make('errors.list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php if(Session::has('flash_mess')): ?>
                <div class="panel">
                    <div class="pos-rlt wrapper b b-light r r-2x bg-success">
                        <span class="arrow left pull-up arrow-success"></span>
                        <p class="m-b-none text-white"><?php echo e(Session::get('flash_mess')); ?></p>
                    </div>
                </div>
            <?php endif; ?>

            <div class="col-sm-9">
                <div class="panel" style="padding: 25px;">
                    <?php if(!$topics->isEmpty()): ?>
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <thead>
                                    <tr>
                                        <th>Topic Name</th>
                                        <th>Duration</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <?php foreach($topics as $topic): ?>
                                    <tr>
                                        <td><?php echo e($topic->name); ?></td>
                                        <td><?php echo e($topic->duration); ?> mins</td>
                                        <td>
                                            <h4>
                                            <?php if($topic->status == 1): ?>
                                                <span class="label label-success">Completed
                                             <?php else: ?>
                                                <span class="label label-warning">Open
                                            <?php endif; ?>

                                                </span>
                                            </h4>
                                        </td>
                                        <td>
                                            <a class="btn btn-info" href="<?php echo e(action('ExamController@getQuestions', [$course->id,$topic->id])); ?>">Manage Questions</a>
                                            <a class="btn btn-warning" href="<?php echo e(action('ExamController@getEdit', [$course->id,$topic->id])); ?>">Edit</a>
                                            <a class="btn btn-danger" id="btn-delete" href="<?php echo e(action('ExamController@getDelete', [$course->id,$topic->id])); ?>">Delete</a>
                                        </td>

                                    </tr>
                                <?php endforeach; ?>

                            </table>
                        </div>
                    <?php else: ?>
                        <div class="panel">
                            <div class="pos-rlt wrapper b b-light r r-2x bg-danger">
                                <span class="arrow left pull-up arrow-danger"></span>
                                <p class="m-b-none text-white">No exam topic found for this Course!</p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>


             <div class="col-sm-3">
                <!-- left sidebar -->
                <div class="panel wrapper-xl bg-offWhite text-center">
                    <a href="<?php echo e(url('teacher/my-course')); ?>/<?php echo e($course->id); ?>" class="btn btn-lg"><i class="fa fa-hand-o-left" aria-hidden="true"></i> Back to course page</a>
                </div>
                <div class="panel wrapper-xl bg-offWhite text-center">
                    <a href="<?php echo e(url('exam/course')); ?>/<?php echo e($course->id); ?>/topic/new" class="btn btn-lg">+ Create an exam topic</a>
                </div>
            </div>
        </div>
    </div>
    <?php if(count($topics) > 0): ?>
     <?php echo e($topics->links()); ?>

     <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>