<tr id="post-<?php echo e($post->sequence); ?>" class="<?php echo e($post->trashed() ? 'deleted' : ''); ?>" class="post-body">
    <td class="author-info">
        <strong><?php echo $post->authorName; ?></strong>
    </td>
    <td class="content">
        <?php if(!is_null($post->parent)): ?>
            <p>
                <strong>
                    <?php echo e(trans('forum::general.response_to', ['item' => $post->parent->authorName])); ?>

                    (<a href="<?php echo e(Forum::route('post.show', $post->parent)); ?>"><?php echo e(trans('forum::posts.view')); ?></a>):
                </strong>
            </p>
            <blockquote>
                <?php echo str_limit(Forum::render($post->parent->content)); ?>

            </blockquote>
        <?php endif; ?>

        <?php if($post->trashed()): ?>
            <span class="label label-danger"><?php echo e(trans('forum::general.deleted')); ?></span>
        <?php else: ?>
            <?php echo Forum::render($post->content); ?>

        <?php endif; ?>
    </td>
</tr>
<tr class="post-footer">
    <td>
        <?php if(!$post->trashed()): ?>
            <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('edit', $post)): ?>
                <a href="<?php echo e(Forum::route('post.edit', $post)); ?>" class="btn btn-sm btn-danger"><?php echo e(trans('forum::general.edit')); ?></a>
            <?php endif; ?>
        <?php endif; ?>
    </td>
    <td class="text-muted">
        <?php echo e(trans('forum::general.posted')); ?> <?php echo e($post->posted); ?>

        <?php if($post->hasBeenUpdated()): ?>
            | <?php echo e(trans('forum::general.last_updated')); ?> <?php echo e($post->updated); ?>

        <?php endif; ?>
        <span class="pull-right">
            <a href="<?php echo e(Forum::route('thread.show', $post)); ?>">#<?php echo e($post->sequence); ?></a>
            <?php if(!$post->trashed()): ?>
                <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('reply', $post->thread)): ?>
                    - <a href="<?php echo e(Forum::route('post.create', $post)); ?>"><?php echo e(trans('forum::general.reply')); ?></a>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(Request::fullUrl() != Forum::route('post.show', $post)): ?>
                - <a href="<?php echo e(Forum::route('post.show', $post)); ?>"><?php echo e(trans('forum::posts.view')); ?></a>
            <?php endif; ?>
            <?php if(isset($thread)): ?>
                <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('deletePosts', $thread)): ?>
                    <?php if(!$post->isFirst): ?>
                        <input type="checkbox" name="items[]" value="<?php echo e($post->id); ?>">
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        </span>
    </td>
</tr>
