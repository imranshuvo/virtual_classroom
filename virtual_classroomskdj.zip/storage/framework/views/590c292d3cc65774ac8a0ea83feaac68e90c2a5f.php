<div class="panel panel-default hidden" data-actions data-bulk-actions>
    <div class="panel-heading"><?php echo e(trans('forum::general.with_selection')); ?></div>
    <div class="panel-body">
        <div class="form-group">
            <label for="thread-action"><?php echo e(trans_choice('forum::general.actions', 1)); ?></label>
            <select name="action" id="thread-action" class="form-control">
                <option value="delete" data-confirm="true" data-method="delete"><?php echo e(trans('forum::general.delete')); ?></option>
                <option value="restore" data-confirm="true"><?php echo e(trans('forum::general.restore')); ?></option>
                <option value="permadelete" data-confirm="true" data-method="delete"><?php echo e(trans('forum::general.perma_delete')); ?></option>
            </select>
        </div>
    </div>
    <div class="panel-footer clearfix">
        <button type="submit" class="btn btn-danger pull-right"><?php echo e(trans('forum::general.proceed')); ?></button>
    </div>
</div>
