<?php $__env->startSection('content'); ?>
    <div id="post">
        <h2><?php echo e(trans('forum::posts.view')); ?> (<?php echo e($thread->title); ?>)</h2>

        <a href="<?php echo e(Forum::route('thread.show', $thread)); ?>" class="btn btn-default">&laquo; <?php echo e(trans('forum::threads.view')); ?></a>

        <table class="table">
            <thead>
                <tr>
                    <th class="col-md-2">
                        <?php echo e(trans('forum::general.author')); ?>

                    </th>
                    <th>
                        <?php echo e(trans_choice('forum::posts.post', 1)); ?>

                    </th>
                </tr>
            </thead>
            <tbody>
                <?php echo $__env->make('forum::post.partials.list', compact('post'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('forum::master', ['breadcrumb_other' => trans('forum::posts.view')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>