<?php $__env->startSection('content'); ?>
    <div id="create-thread">
        <h2><?php echo e(trans('forum::threads.new_thread')); ?> (<?php echo e($category->title); ?>)</h2>

        <form method="POST" action="<?php echo e(Forum::route('thread.store', $category)); ?>">
            <?php echo csrf_field(); ?>

            <?php echo method_field('post'); ?>


            <div class="form-group">
                <label for="title"><?php echo e(trans('forum::general.title')); ?></label>
                <input type="text" name="title" value="<?php echo e(old('title')); ?>" class="form-control">
            </div>

            <div class="form-group">
                <textarea name="content" class="form-control"><?php echo e(old('content')); ?></textarea>
            </div>

            <button type="submit" class="btn btn-success pull-right"><?php echo e(trans('forum::general.create')); ?></button>
            <a href="<?php echo e(URL::previous()); ?>" class="btn btn-danger"><?php echo e(trans('forum::general.cancel')); ?></a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('forum::master', ['breadcrumb_other' => trans('forum::threads.new_thread')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>