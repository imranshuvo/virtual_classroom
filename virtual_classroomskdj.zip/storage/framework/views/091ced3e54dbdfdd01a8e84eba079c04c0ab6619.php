<?php if(Auth::check()): ?>
<ul class="confer-conversation-list">
<?php if($bar_conversations->isEmpty()): ?>
<p style="padding: 10px;">No conversations have been started.</p>
<?php else: ?>
<?php foreach($bar_conversations as $conversation): ?>
	<li data-conversationId="<?php echo e($conversation->id); ?>" <?php if($conversation->is_private): ?> data-userId="<?php echo e($conversation->participants()->ignoreMe()->first()->id); ?>" <?php endif; ?>>
	<h3><?php echo e($conversation->name); ?></h3>
	<?php if($conversation->messages->last()->type === 'user_message'): ?>
	<span class="confer-bar-user-message">
		<strong><?php echo e($conversation->messages->last()->sender->name); ?>: </strong><?php echo e($conversation->messages->last()->body); ?>

	</span>
	<?php else: ?>
	<span class="confer-bar-conversation-message">
		<?php echo $conversation->messages->last()->body; ?>

	</span>
	<?php endif; ?>
	</span>
	<span class="confer-bar-timestamp"><?php echo e($conversation->messages->last()->created_at->diffForHumans()); ?></span>
	</li>
<?php endforeach; ?>
<?php endif; ?>
</ul>
<button class="confer-button confer-button-neutral confer-show-all-conversations">See all conversations</button>
<?php endif; ?>