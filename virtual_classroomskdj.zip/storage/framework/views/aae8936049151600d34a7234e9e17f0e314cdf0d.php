<div class="col-md-3">
    <!-- left sidebar -->
    <div class="list-group">
          <a href="<?php echo e(url('exam/course')); ?>/<?php echo e($course->id); ?>/topic/new" class="list-group-item">Create an exam topic.</a>
    </div>
</div>