<h2><?php echo e($conversation->is_private ? 'Your private conversation with ' . $conversation->participants()->ignoreMe()->first()->name : $conversation->name); ?></h2>
<small>
<?php if($conversation->isGlobal()): ?>
Conversation between all users.
<?php else: ?>
Conversation between <?php echo e(confer_make_list($conversation->participants->lists('name'))); ?>.
<?php endif; ?>
</small>
<?php if( ! $conversation->isGlobal()): ?>
<div class="confer-conversation-options">
	<i class="fa fa-user-plus confer-invite-users"></i>
	<?php if($conversation->participants->count() > 2): ?>
	<i class="fa fa-sign-out confer-leave-conversation"></i>
	<?php endif; ?>
</div>
<?php endif; ?>

<ul class="confer-conversation-message-list" data-conversationId="<?php echo e($conversation->id); ?>">
	<?php if( ! $messages->isEmpty() && $messages->count() > 4): ?>
		<div class="confer-load-more-messages">
			<span>Previous messages...</span>
		</div>
	<?php endif; ?>
	<?php foreach($messages as $message): ?>
	<?php if($message->type === 'user_message'): ?>
		<li data-messageId="<?php echo e($message->id); ?>" class="<?php echo e($message->sender->id === Auth::user()->id ? 'confer-sent-message' : 'confer-received-message'); ?>">
			<img class="confer-user-avatar <?php echo e($message->sender->id === Auth::user()->id ? 'confer-sent-avatar' : 'confer-received-avatar'); ?>" src="<?php echo e(url('/') . config('confer.avatar_dir') . $message->sender->avatar); ?>">
			<div class="confer-message-inner">
				<span class="confer-message-sender"><?php echo e($message->sender->name); ?></span>
				<span class="confer-message-body"><?php echo e($message->body); ?></span>
				<span class="confer-message-timestamp" data-timestamp="<?php echo e($message->created_at->toDateTimeString()); ?>"><?php echo e($message->created_at->diffForHumans()); ?></span>
			</div>
		</li>
	<?php else: ?>
		<li data-messageId="<?php echo e($message->id); ?>" class="confer-conversation-message">
			<span><?php echo $message->body; ?></span>
			<span class="confer-message-timestamp" data-timestamp="<?php echo e($message->created_at->toDateTimeString()); ?>"><?php echo e($message->created_at->diffForHumans()); ?></span>
		</li>
	<?php endif; ?>
	<?php endforeach; ?>
</ul>

<?php echo Form::open(['route' => ['confer.conversation.message.store', $conversation->id], 'class' => 'confer-new-message-form']); ?>

<?php echo Form::label('body', 'New message'); ?>

<?php echo Form::textarea('body', null, ['class' => 'confer-new-message-input']); ?>

<?php echo Form::submit('Send', ['class' => 'confer-button confer-button-neutral confer-new-message-submit']); ?>

<?php echo Form::close(); ?>