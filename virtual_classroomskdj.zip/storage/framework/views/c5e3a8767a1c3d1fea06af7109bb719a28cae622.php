<?php $__env->startSection('content'); ?>


<section class="bg-dark">
    <div class="container">
        <div class="row p-t-xxl">
            <div class="col-sm-8 col-sm-offset-2 p-v-xxl text-center">
                <h1 class="h1 m-t-l p-v-l"><?php echo e($course->title); ?></h1>
            </div>
        </div>
    </div>
</section>

    
<section class="p-v-xxl bg-light">
    <div class="container">
        <div class="row p-t-xxl bg-info content">

            <div class="col-md-3">
                <!-- left sidebar -->
                <div class="list-group">
                      <a href="<?php echo e(url('student')); ?>/my-course/<?php echo e($course->id); ?>" class="list-group-item"><< Back to course page</a>
                </div>
            </div>

            <div class="col-md-9">
                <!-- Main content -->
                    <?php if(count($exams) > 0): ?>
                    <ul> 
                        <?php foreach($exams as $exam): ?>
                            <li><?php echo e($exam->name); ?><a href="<?php echo e(url('exam/course')); ?>/<?php echo e($course->id); ?>/topic/<?php echo e($exam->id); ?>/start" class="btn btn-info">Take it</a></li>
                        <?php endforeach; ?>
                    </ul>
                    <?php else: ?>
                        <span class="alert">No open examination is found.</span>
                    <?php endif; ?>


            </div>

        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>